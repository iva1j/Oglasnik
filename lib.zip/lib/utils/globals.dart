library my_prj.globals;

bool validSignIn = false;
