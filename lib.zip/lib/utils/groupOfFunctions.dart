import 'package:flutter/material.dart';

class InputFields {
  TextEditingController emailInputController = new TextEditingController();
  TextEditingController passwordInputController = new TextEditingController();
}

class PswChangeFields {
  // TextEditingController _email = new TextEditingController();
  // TextEditingController _displayName = new TextEditingController();
  // TextEditingController _password = new TextEditingController();
}

// class PswCopyFields {
//   TextEditingController _email = new TextEditingController();
//   TextEditingController _name = new TextEditingController();
// }

class RegisterControllers {
  TextEditingController fullNameInputController = new TextEditingController();
  TextEditingController phoneNumberInputController =
      new TextEditingController();
  TextEditingController emailInputController = new TextEditingController();
  TextEditingController passwordInputController = new TextEditingController();
}
